﻿using BankingApp.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace BankingApp.Controllers
{
    [Authorize]
    public class TransactionController : Controller
    {

       private ApplicationDbContext db = new ApplicationDbContext();
        // GET: Transaction/Deposit
        public ActionResult Deposit()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Deposit(Transaction transaction)
        {
            if (ModelState.IsValid)
            {
                int transid = transaction.CheckingAccountId;
                /*CheckingAccount balanceam = db.CheckingAccount.Find(transid);
                decimal newbal = balanceam.Balance + transaction.Amount;
                CheckingAccount ca1 =  transaction.CheckingAccount;
                ca1.Balance = newbal;
                db.CheckingAccount.Add(ca1);
                db.Transactions.Add(transaction);*/
                db.SaveChanges();
                return RedirectToAction("Index", "Home");
            }
            return View();
        }
        public ActionResult Withdrawl()
        {
            return View();
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="transaction"></param>
        /// <returns></returns>
        [HttpPost]
        public ActionResult Withdrawl(Transaction transaction)
        {
            if (ModelState.IsValid)
            {
                int transid = transaction.CheckingAccountId;
                /*CheckingAccount balanceam = db.CheckingAccount.Find(transid);
                decimal newbal = balanceam.Balance - transaction.Amount;
                CheckingAccount ca1 = transaction.CheckingAccount;
                ca1.Balance = newbal;
                db.CheckingAccount.Add(ca1);*/
                db.Transactions.Add(transaction);
                
                db.SaveChanges();
                return RedirectToAction("Index", "Home");
            }
            return View();
        }

        public ActionResult ViewTransactions(CheckingAccount ca)
        {
            ICollection<Transaction> tr = ca.Transactions;
            return View(tr);
        }
    }
}