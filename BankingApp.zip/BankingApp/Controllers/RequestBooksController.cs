﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace BankingApp.Controllers
{
    public class RequestBooksController : Controller
    {
        // GET: RequestBooks
        public ActionResult RequestBooks()
        {
            return View();
        }
        [HttpPost]
        public ActionResult RequestBooks(string Cal)
        {
            switch (Cal)
            {
                case "Simple Intrest":
                    ViewBag.Result = "Your Chequebook request has been approved so please collect it from you nearest branch.";
                    break;
                case "Compund Intrest":
                    ViewBag.Result = "Your debit card request has been approved and will be delivered to your registered address.";
                    break;
                
            }
            return View();
        }
      
    }
}