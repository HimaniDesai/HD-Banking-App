﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace BankingApp.Controllers
{
    public class CalculateIntrestController : Controller
    {
        // GET: CalculateIntrest
        public ActionResult CalculateIntrest()
        {
            
            return View();
        }
        [HttpPost]
        public ActionResult CalculateIntrest(string firstNumber, string secondNumber, string Cal)
        {
            double a = Convert.ToDouble(firstNumber);
            double b = Convert.ToDouble(secondNumber);
            double c = 0;
            switch (Cal)
            {
                case "Simple Intrest":
                    double rate = Convert.ToDouble(5);
                    c = (a*b*rate)/(100);
                    break;
                case "Compund Intrest":
                    double ratec = Convert.ToDouble(5);
                    double x = Math.Pow((1 + (ratec / b)), (4 * b));
                    c = a*x;
                    break;
                case "Savings Acc":
                    double rates = Convert.ToDouble(5);
                    c = (a * b) * (rates/100);
                    break;
            }
            ViewBag.Result = c.ToString();
            return View();
        }

    }
    
}